
package employee.management.system;
import java.sql.*;
public class connection {
     Connection c;
     Statement s;
    public connection()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///employemanagementsystem","root","Kishan@12345");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
