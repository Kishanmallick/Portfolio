
package employee.management.system;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

 
public class EmployeeLogin extends JFrame implements ActionListener {
    
    JTextField Emptxt,passwordtxt;
    JButton login,New,forgotpswd,Back;
    EmployeeLogin(){
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        
        
        
        JLabel EmpID = new JLabel("EmpID");
        EmpID.setBounds(40,20,100,30);
        add(EmpID);
        
        Emptxt = new JTextField();
        Emptxt.setBounds(140,20,150,30);
        add(Emptxt);
        
        JLabel password = new JLabel("Password");
        password.setBounds(40,80,100,30);
        add(password);
        
        passwordtxt = new JTextField();
        passwordtxt.setBounds(140,80,150,30);
        add(passwordtxt);
       
        
      login = new JButton("login");
      login.setBounds(150,150,100,40);
      login.setBackground(Color.BLACK);
      login.setForeground(Color.WHITE);
      login.addActionListener(this);
      add(login);
      
      New = new JButton("New");
       New.setBounds(5,150,100,40);
      New.setBackground(Color.BLACK);
      New.setForeground(Color.WHITE);
      New.addActionListener(this);
      add(New);
      
      JButton forgotPswd = new JButton("ForgotPassword");
      forgotPswd.setBounds(300,150,150,40);
      forgotPswd.setBackground(Color.BLACK);
      forgotPswd.setForeground(Color.WHITE);
      add(forgotPswd);
      
      Back = new JButton("Back");
      Back.setBounds(350,250,150,40);
       Back.addActionListener(this);
      Back.setBackground(Color.BLACK);
     Back.setForeground(Color.WHITE);
      add(Back);
      
      
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/second.jpg"));
      Image i2 = i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(300, 20, 100, 100);
      add(images);
      
      
      
        setSize(600,400);
        setLocation(400,140);
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        
        
    }
    public void actionPerformed(ActionEvent aw)
    {
        if(aw.getSource() == login)
        {
       try {
            String EmpID = Emptxt.getText();
            String password = passwordtxt.getText();
            connection c = new connection();
             String query = "select * from Empdetail where EmpID = '"+EmpID+"' and password = '"+password+"' ";
            
             ResultSet rs = c.s.executeQuery(query);
             if(rs.next())
             {
                 JOptionPane.showMessageDialog(null,"Login SuccesFully");
                 setVisible(false);
                 new EmployeeHome();
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"Invalid username or password");
             }
             
             
        } catch (Exception e){
            e.printStackTrace();
        }
        }
        else if(aw.getSource() == New)
        {
            setVisible(false);
            new NewLogin();
        }
        else if(aw.getSource() == Back)
        {
            setVisible(false);
            new EmployeeType();
        }
        else{
            
        }
    
    }  
    public static void main(String[] args) {
        new EmployeeLogin();
    }
}
