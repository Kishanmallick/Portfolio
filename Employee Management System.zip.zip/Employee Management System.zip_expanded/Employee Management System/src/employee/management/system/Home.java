
package employee.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Home extends JFrame implements ActionListener{
    JButton Add,View,Update,Remove;
    Home()
    {
        setLayout(null);
         getContentPane().setBackground(Color.WHITE);
         
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/home.jpg"));
      Image i2 = i1.getImage().getScaledInstance(1100,800, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(40,40, 1100, 800);
      add(images);
      
      JLabel heading = new JLabel("EmployeeManagementSystem");
      heading.setBounds(670, 0, 600, 50);
      heading.setFont(new Font("serif",Font.BOLD,25));
      images.add(heading);
      
      Add = new JButton("AddEmployee");
      Add.setBounds(670,70,150,40);
      Add.setBackground(Color.WHITE);
      Add.setForeground(Color.BLACK);
      Add.addActionListener(this);
      images.add(Add);
      View = new JButton("ViewDetails");
      View.setBounds(850,70,150,40);
      View.setBackground(Color.WHITE);
      View.setForeground(Color.BLACK);
      View.addActionListener(this);
      images.add(View);
      Update = new JButton("UpdatDetails");
      Update.setBounds(670,140,150,40);
      Update.setBackground(Color.WHITE);
      Update.setForeground(Color.BLACK);
      Update.addActionListener(this);
      images.add(Update);
      
      Remove = new JButton("Remove");
      Remove.setBounds(850,140,150,40);
      Remove.setBackground(Color.WHITE);
      Remove.setForeground(Color.BLACK);
      Remove.addActionListener(this);
      images.add(Remove);
            
    
        
        setSize(1200,800);
        setLocation(200, 50);
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    public void actionPerformed(ActionEvent aw){
        
        if(aw.getSource() == Add)
            
        {
            setVisible(false);
            new Add();
            
        }else if(aw.getSource() == View)
        {
            setVisible(false);
            new ViewEmployee();
        }else if(aw.getSource() == Add)
        {
            
        }else
        {
    }
    }
    public static void main(String[] args) {
        new Home();
    }
}
