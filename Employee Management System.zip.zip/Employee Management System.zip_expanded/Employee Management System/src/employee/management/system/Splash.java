package employee.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class Splash extends JFrame implements ActionListener{
    
  Splash(){
      getContentPane().setBackground(Color.WHITE);
      setLayout(null);
 
      JLabel h1 = new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
      h1.setBounds(100, 50, 1250, 40);
      h1.setFont(new Font("serif",Font.BOLD,50));
      h1.setForeground(Color.RED);
      add(h1);
      
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/front.jpg"));
      Image i2 = i1.getImage().getScaledInstance(1100,700, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(50, 100, 1000, 500);
      add(images);
      

      JButton clickhere = new JButton("ClickHere");
      clickhere.setBounds(350,400,200,50);
      clickhere.setBackground(Color.WHITE);
      clickhere.setForeground(Color.BLACK);
      clickhere.addActionListener(this);
      images.add(clickhere);
      
    
      setSize(1100,650);
      setLocation(100,100);
      setVisible(true);
      setDefaultCloseOperation(DISPOSE_ON_CLOSE);
     
}
  public void actionPerformed(ActionEvent e){
      setVisible(false);
      new EmployeeType();
  }

    public static void main(String[] args) {
       
 new Splash();
  
}
}
