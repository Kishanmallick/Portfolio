
package employee.management.system;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;


public class Add extends JFrame implements ActionListener{

   Random ran = new Random();
   int number = ran.nextInt(9999999);
     JLabel Name,fName,Dob,salary,Address, PhoneNo,Email,Education,Designation,AadharNo,EmpID;
    JTextField ftName,tName,tsalary,tAddress,tPhoneNo,tEmail,tDesignation,tAadharNo;
    JDateChooser dcdob;
    JButton Add,Back;
    JLabel labelEmpID; 
     JComboBox tEducation;
    Add()
    {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
 
        JLabel heading = new JLabel("AddEmployeeDetails");
        heading.setBounds(320,20,500,50);
        heading.setFont(new Font("serief",Font.BOLD,25));
        add(heading);
        
        
         Name = new JLabel("Name");
         Name.setBounds(50,150,150,30);
         Name.setFont(new Font("serif",Font.PLAIN,20));
         add(Name);
         
         tName = new JTextField("");
         tName.setBounds(200,150,150,30);
         add(tName);
         
         fName = new JLabel("Father's Name");
         fName.setBounds(400,150,150,30);
         fName.setFont(new Font("serif",Font.PLAIN,20));
         add(fName);
         
         ftName = new JTextField("");
         ftName.setBounds(600,150,150,30);
         add(ftName);
        
         Dob = new JLabel("Date Of Birth");
         Dob.setBounds(50,200,150,30);
         Dob.setFont(new Font("serif",Font.PLAIN,20));
         add(Dob);
         
         
         dcdob = new JDateChooser();
         dcdob.setBounds(200, 200, 150, 20);
         add(dcdob);
        
        
        salary = new JLabel("Salary");
         salary.setBounds(400,200,150,30);
         salary.setFont(new Font("serif",Font.PLAIN,20));
         add(salary);
         
         tsalary = new JTextField("");
         tsalary.setBounds(600,200,150,30);
         add(tsalary);
        
                 
        Address= new JLabel("Address");
         Address.setBounds(50,250,150,30);
         Address.setFont(new Font("serif",Font.PLAIN,20));
         add(Address);
         
         tAddress = new JTextField("");
         tAddress.setBounds(200,250,150,30);
         add(tAddress);
        
         PhoneNo = new JLabel("PhNo.");
          PhoneNo.setBounds(400,250,150,30);
          PhoneNo.setFont(new Font("serif",Font.PLAIN,20));
         add( PhoneNo);
         
         tPhoneNo= new JTextField("");
         tPhoneNo.setBounds(600,250,150,30);
         add(tPhoneNo);
        
         
         
         Email= new JLabel("Email");
        Email.setBounds(50,300,150,30);
         Email.setFont(new Font("serif",Font.PLAIN,20));
         add(Email);
         
         tEmail = new JTextField("");
         tEmail.setBounds(200,300,150,30);
         add(tEmail);
        
         
            
            Education = new JLabel("HighestEducation");
            Education.setBounds(400,300,150,30);
          Education.setFont(new Font("serif",Font.PLAIN,20));
         add( Education);
         
         String Course[] = {"10th","12th","BCA","BBA","BA","BSC","BTech","MCA","M.COM","MTech","MA","MBA","M.Sc"};
         tEducation = new JComboBox(Course);
         tEducation.setBackground(Color.WHITE);
        tEducation.setBounds(600,300,150,30);
        add(tEducation);     
         
                  
        Designation= new JLabel("Designation");
         Designation.setBounds(50,350,150,30);
         Designation.setFont(new Font("serif",Font.PLAIN,20));
         add(Designation);
         
         tDesignation = new JTextField("");
         tDesignation.setBounds(200,350,150,30);
         add(tDesignation);
        
         AadharNo = new JLabel("AadharNo.");
          AadharNo.setBounds(400,350,150,30);
          AadharNo.setFont(new Font("serif",Font.PLAIN,20));
         add( AadharNo);
         
         tAadharNo= new JTextField("");
         tAadharNo.setBounds(600,350,150,30);
         add(tAadharNo);
         
         
          JLabel EmpID = new JLabel("EmpID");
          EmpID.setBounds(50,400,150,30);
          EmpID.setFont(new Font("serif",Font.PLAIN,20));
          add( EmpID);
         
         
           labelEmpID = new JLabel("" + number);
          labelEmpID.setBounds(200,400,150,30);
          labelEmpID.setFont(new Font("serif",Font.PLAIN,20));
          add( labelEmpID);
          
      Add = new JButton("AddDetails");
      Add.setBounds(250,550,150,40);
       Add.addActionListener(this);
      Add.setBackground(Color.BLACK);
      Add.setForeground(Color.WHITE); 
      add(Add);
     
      Back = new JButton("Back");
      Back.setBounds(450,550,150,40);
       Back.addActionListener(this);
      Back.setBackground(Color.BLACK);
     Back.setForeground(Color.WHITE);
     
      add(Back);
     
        
         
        setSize(900,700);
        setLocation(300,50);
        setVisible(true);
    }
    
    
   public void actionPerformed(ActionEvent ae)
   {
       //JLabel Name,fName,Dob,salary,Address, PhoneNo,Email,Education,Designation,AadharNo,EmpID;
    //JTextField ftName,tName,tsalary,tAddress, tPhoneNo,tEmail,tDesignation,tAadharNo,tEmpID;
       if(ae.getSource() == Add)
                 
       {
           String Name = tName.getText();
           String fName = ftName.getText();
           String Dob = ((JTextField) dcdob.getDateEditor().getUiComponent()).getText();
           String salary = tsalary.getText();
           String Address = tAddress.getText();
           String PhoneNo = tPhoneNo.getText();
           String Email = tEmail.getText();
           String Education = (String) tEducation.getSelectedItem();
           String Designation = tDesignation.getText();
           String AadharNo = tAadharNo.getText();
           String EmpID = labelEmpID.getText();
           
      try {
           connection c = new connection();
           String query = "insert into employeeDetails values('"+Name+"','"+fName+"','"+Dob+"','"+salary+"','"+Address+"','"+PhoneNo+"','"+Email+"','"+Education+"','"+Designation+"','"+AadharNo+"','"+EmpID+"')";
           c.s.executeUpdate(query);
           JOptionPane.showMessageDialog(null, "successfully Addded");
           setVisible(false);
           new Home();
             
       } catch (Exception e) {
           
           e.printStackTrace();
       }
       }
       
   else{
           setVisible(false);
           new Home();
             
       }
   }
    public static void main(String[] args) {
        new Add();
    }
}
