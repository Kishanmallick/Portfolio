
package employee.management.system;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.sql.*;
import javax.swing.JOptionPane;
public class login extends JFrame implements ActionListener {
    JTextField usernametxt,passwordtxt;
    JButton Back,login,forgotPswd ;
    login()
    {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null); 
        
        
        JLabel username = new JLabel("Username");
        username.setBounds(40,20,100,30);
        add(username);
        
        usernametxt = new JTextField();
        usernametxt.setBounds(140,20,150,30);
        add(usernametxt);
        
        JLabel password = new JLabel("Password");
        password.setBounds(40,80,100,30);
        add(password);
        
         passwordtxt = new JTextField();
        passwordtxt.setBounds(140,80,150,30);
        add(passwordtxt);
       
        
       login = new JButton("login");
      login.setBounds(100,150,100,40);
      login.setBackground(Color.BLACK);
      login.setForeground(Color.WHITE);
      login.addActionListener(this);
      add(login);
      
      
      
      
      Back = new JButton("Back");
      Back.setBounds(250,200,150,40);
       Back.addActionListener(this);
      Back.setBackground(Color.BLACK);
     Back.setForeground(Color.WHITE);
      add(Back);
      
      
       forgotPswd = new JButton("ForgotPassword");
      forgotPswd.setBounds(240,150,150,40);
      forgotPswd.setBackground(Color.BLACK);
      forgotPswd.setForeground(Color.WHITE);
      add(forgotPswd);
      
      
      
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/second.jpg"));
      Image i2 = i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(300, 20, 100, 100);
      add(images);
      
        setSize(600, 300);
        setVisible(true);
        setLocation(450, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
  
    
    }
    public void actionPerformed(ActionEvent aw)
    {
        if(aw.getSource() == login){
        try {
            String username = usernametxt.getText();
            String password = passwordtxt.getText();
            connection c = new connection();
             String query = "select * from UserDetails where username = '"+username+"' and password = '"+password+"' ";
            
             ResultSet rs = c.s.executeQuery(query);
             if(rs.next())
             {
                 JOptionPane.showMessageDialog(null,"Login SuccesFully");
                 setVisible(false);
                 new Home();
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"Invalid username or password");
             }
             
             
        } catch (Exception e){
            e.printStackTrace();
        }
        }
        else if (aw.getSource() == Back)
        {
            setVisible(false);
            new EmployeeType();
        }
    }
    
    public static void main(String[] args) {
         new login();
    }
   
}
