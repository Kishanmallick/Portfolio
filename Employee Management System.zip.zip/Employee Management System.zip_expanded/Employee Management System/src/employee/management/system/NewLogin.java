
package employee.management.system;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.sql.*;
import javax.swing.JOptionPane;


public class NewLogin extends JFrame implements ActionListener {
    
    JButton Register;
    JTextField Emptxt,passwordtxt;
    NewLogin()
    {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
       
         JLabel EmpID = new JLabel("EmpID");
        EmpID.setBounds(40,20,100,30);
        add(EmpID);
        
        Emptxt = new JTextField();
        Emptxt.setBounds(140,20,150,30);
        add(Emptxt);
        
        JLabel password = new JLabel("Password");
        password.setBounds(40,80,100,30);
        add(password);
        
        passwordtxt = new JTextField();
        passwordtxt.setBounds(140,80,150,30);
        add(passwordtxt);
       
        
      Register = new JButton("Register");
      Register.setBounds(150,150,100,40);
      Register.setBackground(Color.BLACK);
      Register.setForeground(Color.WHITE);
      Register.addActionListener(this);
      add(Register);
      
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/second.jpg"));
      Image i2 = i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(300, 20, 100, 100);
      add(images);
      
        
        setSize(600,400);
        setLocation(400,140);
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        

    }
      
    public void actionPerformed(ActionEvent aw)
    {
       
         String EmpID = Emptxt.getText();
           String  password = passwordtxt.getText();
           
            try {
                 connection connect = new connection();
                 String query = "insert into Empdetail values('"+EmpID+"','"+password+"')";
                 connect.s.executeUpdate(query);
                 
                 JOptionPane.showMessageDialog(null, "successfully ");
                setVisible(false);
                 new EmployeeLogin();
                 
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
   
    public static void main(String[] args) {
        new NewLogin();
    }
}
