package employee.management.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.DbUtils;


public class ViewEmployee extends JFrame implements ActionListener{
    
    JTable table; 
     JLabel search1;
    JButton search,update,print,back;
    Choice Box;
    ViewEmployee()
    {
         getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        search1 = new JLabel("search by EmpID");
        search1.setBounds(20,20,150,20);
        add(search1);
        
        Box = new  Choice();
        Box.setBounds(180,20,150,20);
        add(Box);
         try {
            connection c =  new connection();
            ResultSet rs =  c.s.executeQuery("select * from employeedetails");
            while(rs.next()){
                Box.add(rs.getString("Name"));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        table = new JTable();
        
        try {
            connection c =  new connection();
            ResultSet rs =  c.s.executeQuery("select * from employeedetails");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        JScrollPane jsp  = new JScrollPane(table);
        jsp.setBounds(0,100,900,600);
        add(jsp);
        
      search = new JButton("search");
      search.setBounds(20,70,80,20);
      search.setBackground(Color.BLACK);
      search.setForeground(Color.WHITE);
      search.addActionListener(this);
      add(search);
      
      print = new JButton("print");
      print.setBounds(120,70,80,20);
      print.setBackground(Color.BLACK);
      print.setForeground(Color.WHITE);
     print.addActionListener(this);
      add(print);
      
     update = new JButton("update");
      update.setBounds(220,70,80,20);
      update.setBackground(Color.BLACK);
      update.setForeground(Color.WHITE);
      update.addActionListener(this);
      add(update);
      
      back = new JButton("back");
      back.setBounds(320,70,80,20);
      back.setBackground(Color.BLACK);
      back.setForeground(Color.WHITE);
      back.addActionListener(this);
      add(back);
        
       
        setSize(900,700);
        setLocation(300,100);
        setVisible(true);
        setTitle("View");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
    }
   
    public static void main(String[] args) {
        new ViewEmployee();
    }

    @Override
    public void actionPerformed(ActionEvent aw) {
        if(aw.getSource() == search)
        {
            String query = "select * from employeedetails where Name = '"+Box.getSelectedItem()+"'";
            try {
                connection c = new connection();
                ResultSet rs = c.s.executeQuery(query);
                 table.setModel(DbUtils.resultSetToTableModel(rs));
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if(aw.getSource() == print)
        {
            try {
                table.print();
            } catch (Exception e) {
                e.printStackTrace();
            }
                
            
        }else if(aw.getSource() == update)
        {
            
        }else
        {
            setVisible(false);
            new Home();
            
        } 
    }

    
}
