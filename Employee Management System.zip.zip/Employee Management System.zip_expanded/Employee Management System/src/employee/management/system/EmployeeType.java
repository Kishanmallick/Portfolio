
package employee.management.system;

import java.awt.Color;
import static java.awt.Color.WHITE;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import java.awt.event.*;

public class EmployeeType extends JFrame implements ActionListener{
     JButton Emp,Admin;
    EmployeeType()
    {
       getContentPane().setBackground(WHITE);
        setLayout(null);
     
        
        
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/home.jpg"));
      Image i2 = i1.getImage().getScaledInstance(1100,800, Image.SCALE_DEFAULT);
      ImageIcon i3 = new ImageIcon(i2);
      JLabel images = new JLabel(i3);
      images.setBounds(0,0, 1100, 650);
      add(images);
      
      JLabel Heading =  new JLabel("I want to LoginAs...");
      Heading.setBounds(100 , 40, 1120,100);
      Heading.setFont(new Font("serif",Font.BOLD,50));
      Heading.setForeground(Color.BLACK);
      images.add(Heading);
      
      Emp = new JButton("Employee");
      Emp.setBounds(100,150,150,50);
      Emp.addActionListener(this);
      Emp.setBackground(Color.WHITE);
      Emp.setForeground(Color.BLACK);
      images.add(Emp);
      
      Admin = new JButton("Admin");
      Admin.setBounds(350,150,150,50);
      Admin.setBackground(Color.WHITE);
      Admin.addActionListener(this);
      Admin.setForeground(Color.BLACK);
      images.add(Admin);
      
       setSize(1100,650);
      setLocation(100,100);
      setVisible(true);
      setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    public  void actionPerformed(ActionEvent aw)
    {
        if(aw.getSource()== Admin)
        {
            setVisible(false);
             new login();
        }
        else{
            setVisible(false);
           new EmployeeLogin();
        }
    }
    public static void main(String[] args) {
        new EmployeeType();
    }
    
    
}
